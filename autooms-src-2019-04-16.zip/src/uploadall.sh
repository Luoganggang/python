#!/bin/sh

scp -r * redfinger@mcmonitor:/home/redfinger/redfinger/autooms/run


